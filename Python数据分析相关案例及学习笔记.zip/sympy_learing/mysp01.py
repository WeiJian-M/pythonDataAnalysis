import sympy as sp

print(sp.pi.evalf(10000))